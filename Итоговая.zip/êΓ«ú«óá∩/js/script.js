let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>
{
   loginForm.classList.add('active');
}

document.querySelector('#close-login-form').onclick = () =>
{
   loginForm.classList.remove('active');
}

let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .nav');

menu.onclick = () =>
{
   menu.classList.toggle('fa-times');
   navbar.classList.toggle('active');
}

window.onscroll = () =>
{
   loginForm.classList.remove('active');
   menu.classList.remove('fa-times');
   navbar.classList.remove('active');

   if(window.scrollY > 0)
   {
      document.querySelector('.header').classList.add('active');
   }
   else
   {
      document.querySelector('.header').classList.remove('active');
   }
}

document.getElementById('startButton').addEventListener('click', function() 
{
   window.scrollBy
   ({
     top: 1050,
     behavior: 'smooth'
   });
});
 
window.addEventListener('scroll', function() 
 {
   let title = document.querySelector('.home h3');
   let scrolled = window.scrollY;
   title.style.transform = 'translateX('+(-scrolled/1)+'px)';
});

let currentSlide = 1;

function showSlide() 
{
   const slides = document.querySelectorAll('.slider img');
   for (let i = 0; i < slides.length; i++) 
   {
      slides[i].style.display = 'none';
   }
   currentSlide++;
   if (currentSlide > slides.length) 
   {currentSlide = 1;}
   slides[currentSlide - 1].style.display = 'block';
}
setInterval(showSlide, 2000);

